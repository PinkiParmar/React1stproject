import React, {useState, useEffect} from "react";
import {Link, useParams} from "react-router-dom";
import EditModal from "./modal";
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
export default function User(){
{ 
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

    const arrayofUsers = [{FirstName:"Rohit",LastName:"Lalwani",role:"Admin",active:1},
    {FirstName:"Moin Ahmed",LastName:"Khan",role:"User",active:1},
    {FirstName:"Vinit",LastName:"Joshi",role:"Admin",active:1}, 
    {FirstName:"Kuldeep",LastName:"Patel",role:"User",active:1},
    {FirstName:"Hemant",LastName:"Uchchasare",role:"User",active:1},
    {FirstName:"Diksha",LastName:"Patidar",role:"User",active:1},
    {FirstName:"Aasif",LastName:"Umar",role:"User",active:1},
    {FirstName:"Abhishek",LastName:"Rathore",role:"User",active:1},
    {FirstName:"Akshay",LastName:"Chouhan",role:"User",active:1},
    {FirstName:"Rajat",LastName:"Gite",role:"User",active:1},
    {FirstName:"Praveen",LastName:"Patel",role:"user",active:1},
    {FirstName:"Rakesh",LastName:"Diwan",role:"User",active:1}];
    const [users, setUsers]=React.useState(arrayofUsers);



                 useEffect(()=>{
                  console.log(users)
                 }, [users])    
    
             const editDetails=(id)=>{
              handleShow();
             }
           const deleteDetails = (id)=>{
            var array = users
            array.splice(id, 1);
            console.log(id);
            console.log(array);
          setUsers(array);

            }
            

         
          
             return(<div>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Edit User</Modal.Title>
        </Modal.Header>
        <Modal.Body>
              <div className="d-flex w-100 vh-50 justify-content-center align-items-center">
        <div className="w-70 border bg-secondary text-white p-5">
            <form>
                <div>
                    <label htmlFor="name" style={{float: "left"}}>First Name:</label>
                    <input type="text" name="name" className="form-control" placeholder="First Name"/>
                </div>
                <div>
                    <label htmlFor="name" style={{float: "left"}}>Last Name:</label>
                    <input type="text" name="name" className="form-control" placeholder="Last Name"/>
                </div>
                <div>
                    <label htmlFor="name" style={{float: "left"}}>role:</label>
                    <input type="text" name="name" className="form-control" placeholder="role"/>
                </div>
                <br></br>
                <div>
                    <label htmlFor="name" style={{float: "left"}}>Active:</label>&nbsp;&nbsp;
                    {/* <input type="text" name="name" className="form-control" placeholder="Active"/> */}
          
                    <select  >
                      <option>0</option>
                      <option>1</option>
                    </select>
                </div>
                
            </form>
        </div>
    </div>

        </Modal.Body>
        <Modal.Footer>
          {/* <Button variant="secondary" onClick={handleClose}>
            Close
          </Button> */}
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

                 <table  align='center' cellSpacing='8' cellPadding='8' border='2'>
                  <thead>
                     <tr>
                         <th>Sno</th>
                         <th>First Name</th>
                         <th>Last Name</th>
                         <th>Role</th>
                         <th>Active</th>
                         <th>Operation</th>
                     </tr>
                  </thead>
         <tbody>
                  {users.map((data,index)=>{
                        return<tr key={index}>
                         <td>{index+1}</td>
                         <td>{data.FirstName}</td>
                         <td>{data.LastName}</td>
                         <td>{data.role}</td>
                         <td>{data.active}</td>
                         <td><button className="btn btn-primary btn-floating mx-1" onClick={()=>editDetails(index)}>Edit</button> &nbsp; ||  &nbsp;
                              <button className="btn btn-danger btn-floating mx-1" onClick={()=>deleteDetails(index) }>Delete</button></td>
                        </tr>
                  })}
         </tbody>
                 </table>
                
             </div>)
           }
         }
        
    


